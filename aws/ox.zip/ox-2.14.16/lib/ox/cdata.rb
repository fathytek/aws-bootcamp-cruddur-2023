module Ox
  # CData represents a CDATA element in an XML document.
  class CData < Node
    # Creates a CDATA element.
    # - +value+ [String] value for the CDATA contents
    def initialize(value)
      super
    end
  end # CData
end # Ox
