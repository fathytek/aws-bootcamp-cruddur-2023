module Ox
  # Represents a DOCTYPE in an XML document.
  class DocType < Node
    # Creates a DOCTYPE elements with the content as a string specified in the
    # value parameter.
    # - +value+ [String] string value for the element
    def initialize(value)
      super
    end
  end # DocType
end # Ox
