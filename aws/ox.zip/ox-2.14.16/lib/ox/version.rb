module Ox
  # Current version of the module.
  VERSION = '2.14.16'
end
